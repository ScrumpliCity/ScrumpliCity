# ScrumpliCity - Bastelvorlagen

Hier finden Sie eine kurze Einführung und Anleitung zu den Bastelvorlagen von ScrumpliCity.

## Legende

**\_\_\_\_\_\_\_** → schneiden

------- → falten

## Benötigte Materialien

- ScrumpliCity-Bastelbögen (schwarz-weiß: es wird kein Farbdruck benötigt)
- Schere
- Bunte Stifte

Die Bastelvorlagen sind so gestaltet, dass sie lediglich mit den ausgedruckten Templates und einer Schere umgesetzt werden können. Kleber oder andere Hilfsmittel werden nicht benötigt.

## Wie viele Bastelbögen?

Grundsätzlich hängt die benötigte Anzahl an Bastelbögen von der Anzahl der Teams und den Teamgrößen ab - also davon, wie viele Lernende mitspielen. Als Referenz jedoch: das ScrumpliCity-Team braucht in etwa 3min für das Ausschneiden, Falten und Stecken eines normal großen Hauses. Hinzu kommt jedoch noch die Zeit für das Malen und Ausmalen. Es ist also schwierig zu sagen, wie viele Bögen benötigt werden, jedoch: Bögen können auch nachgedruckt werden! Achten Sie darauf, dass ScrumpliCity nicht Schuld trägt an einer signifikant erhöhten Papierverschwendung :)

## Inspirationen zum ausmalen

- **Normales Haus:** Einfamilienhaus, Marktstand, Kaffeeshop, Restaurant
- **Hohes Haus:** Hochhaus, Mehrfamilienhaus, Post
- **Breites Haus:** Supermarkt, Schule, Krankenhaus, Feuerwehr, Museum
  → Tipp: das Schild vorne eignet sich gut für eine Bezeichnung der Einrichtung!

Viel Spaß :)

---

English Version:

# ScrumpliCity - Crafting Templates

Here you will find a short introduction an instructions for the ScrumpliCity crafting templates.

## Key

**\_\_\_\_\_\_\_** → cut

------- → fold

## Materials required

- ScrumpliCity crafting templates (black and white: no color printing required)
- Scissors
- Colored pens

The crafting templates are designed so that they can be made using only the printed templates and scissors. Glue or other tools are not required.

## How many crafting templates?

Basically, the number of crafting templates required depends on the number of teams and team sizes - i.e. how many learners are playing. As a reference, the ScrumpliCity team needs about 3 minutes to cut out, fold and stick together a normal-sized house. However, there is also spare time for painting and coloring. So it is difficult to say how many sheets are needed, but: sheets can also be reprinted! Make sure that ScrumpliCity is not to blame for a significantly increased waste of paper :)

## Inspirations for coloring

- **Normal house:** Single-family house, market stall, coffee shop, restaurant
- **Tall house:** High-rise building, apartment building, post office
- **Wide house:** Supermarket, school, hospital, fire station, museum
  → Tip: the sign at the front is a good place to name the establishment!

Have fun :)
